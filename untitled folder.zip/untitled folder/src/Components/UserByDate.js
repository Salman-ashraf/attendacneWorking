const userbydate={"data":
[{"id":1,
"attendanceTime":"6/18/2022, 9:53:07 AM",
"createdAt":"2022-12-01T08:46:16.155Z",
"updatedAt":"2022-12-01T08:46:16.155Z",
"employeeId":1,
"employee":[{"id":1,"name":"Junaid",
"designation":"Tech lead","email":"junaid122@gmail.com","deviceId":12,"createdAt":"2022-12-01T08:46:09.993Z","updatedAt":"2022-12-01T12:46:00.759Z"}]}],
"success":true}

export default userbydate;