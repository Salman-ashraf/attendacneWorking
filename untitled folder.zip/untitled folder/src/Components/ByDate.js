export const databydate = {
  data: [
  
    {
      id: 1,
      attendanceTime: "2022-12-01T08:28:00.993Z",
      createdAt: "2022-12-01T08:46:16.155Z",
      updatedAt: "2022-12-01T08:46:16.155Z",
      employeeId: 1,
      employee: 
        {
          id: 1,
          name: "haider",
          designation: "junior software engineer",
          email: "haider127@gmail.com",
          deviceId: 31,
          createdAt: "2022-12-01T08:46:09.993Z",
          updatedAt: "2022-12-05T10:14:57.437Z",
        },

    },


    {
      id: 2,
      attendanceTime: "2022-12-01T11:59:09.993Z",
      createdAt: "2022-12-01T08:46:16.268Z",
      updatedAt: "2022-12-01T08:46:16.268Z",
      employeeId: 1,
      employee: 
        {
          id: 1,
          name: "haider",
          designation: "junior software engineer",
          email: "haider127@gmail.com",
          deviceId: 31,
          createdAt: "2022-12-01T08:46:09.993Z",
          updatedAt: "2022-12-05T10:14:57.437Z",
        },
      
    },




    {
      id: 3,
      attendanceTime: "2022-12-01T12:12:09.993Z",
      createdAt: "2022-12-01T08:46:16.327Z",
      updatedAt: "2022-12-01T08:46:16.327Z",
      employeeId: 1,
      employee: 
        {
          id: 1,
          name: "haider",
          designation: "junior software engineer",
          email: "haider127@gmail.com",
          deviceId: 31,
          createdAt: "2022-12-01T08:46:09.993Z",
          updatedAt: "2022-12-05T10:14:57.437Z",
        }
      
    },

    {
        id: 4,
        attendanceTime: "2022-12-01T17:12:09.993Z",
        createdAt: "2022-12-01T08:46:16.327Z",
        updatedAt: "2022-12-01T08:46:16.327Z",
        employeeId: 1,
        employee: 
          {
            id: 1,
            name: "haider",
            designation: "junior software engineer",
            email: "haider127@gmail.com",
            deviceId: 31,
            createdAt: "2022-12-01T08:46:09.993Z",
            updatedAt: "2022-12-05T10:14:57.437Z",
          }
        
      },

      {
        id: 5,
        attendanceTime: "2022-12-01T08:07:09.993Z",
        createdAt: "2022-12-01T08:46:16.327Z",
        updatedAt: "2022-12-01T08:46:16.327Z",
        employeeId: 2,
        employee: 
          {
            id: 1,
            name: "salman",
            designation: "junior software engineer",
            email: "haider127@gmail.com",
            deviceId: 31,
            createdAt: "2022-12-01T08:46:09.993Z",
            updatedAt: "2022-12-05T10:14:57.437Z",
          }
        
      },


  ],
  success: true,
};
